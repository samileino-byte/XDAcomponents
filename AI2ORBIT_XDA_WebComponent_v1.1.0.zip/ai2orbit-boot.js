/**
 * ai2orbit-boot.js - AI2ORBIT Bootloader Web Component
 *
 * W3C Custom Elements v1 / Shadow DOM v1 compliant.
 * Works in all modern browsers: Chrome, Firefox, Safari, Edge, Opera.
 * Compatible with Android WebView and iOS WKWebView.
 *
 * Usage:
 *   <script src="ai2orbit-boot.js"></script>
 *   <ai2orbit-boot></ai2orbit-boot>
 *
 * Attributes:
 *   platform="Android|iOS|Windows|Linux|macOS"  (auto-detected if omitted)
 *   form-factor="Phone|Tablet|Desktop"          (auto-detected if omitted)
 *   autostart                                    (start boot on connect)
 *
 * Methods:
 *   element.startBoot()   - start the boot sequence
 *   element.getResult()   - get boot result object after READY
 *
 * Events:
 *   'boot-progress'  detail: { stage, progress }
 *   'boot-ready'     detail: { result }
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 */

(function () {
  'use strict';

  const VERSION = '1.1.0';
  const NUM_TIMING_OPTIONS = 244;
  const MIN_TIMING_OPTIONS = 45;
  const LOADER_DURATION_MS = 700;
  const DRAM_LOOP_COUNT = 4;
  const DRAM_PASS_TARGET_MS = 100;

  const BROWSER_SPEEDUP_MIN = 15.0;
  const NETWORK_SPEEDUP_MIN = 30.0;
  const SCREEN_SPEEDUP_MIN = 350.0;
  const SCREEN_SPEEDUP_MAX = 550.0;

  const TEMPLATE = document.createElement('template');
  TEMPLATE.innerHTML = `
    <style>
      :host {
        display: block;
        width: 100%;
        height: 100%;
        background: #000;
        color: #ccc;
        font-family: 'Courier New', Consolas, monospace;
        font-size: 13px;
        line-height: 1.5;
        overflow-y: auto;
        padding: 12px 16px;
        box-sizing: border-box;
      }
      .header { color: #fff; font-weight: bold; }
      .gold { color: #D4A853; }
      .status { color: #ddd; }
      .value { color: #888; }
      .ready-banner { color: #00c853; font-weight: bold; }
      .bar-container { color: #ddd; white-space: pre; }
      .copyright { color: #666; }
      pre { margin: 0; font-family: inherit; font-size: inherit; line-height: inherit; }
    </style>
    <div id="output"></div>
  `;

  function detectPlatform() {
    var ua = navigator.userAgent || '';
    if (/android/i.test(ua)) return 'Android';
    if (/iPad|iPhone|iPod/.test(ua)) return 'iOS';
    if (/Macintosh|Mac OS/i.test(ua)) return 'macOS';
    if (/Windows/i.test(ua)) return 'Windows';
    return 'Linux';
  }

  function detectFormFactor() {
    var w = screen.width || window.innerWidth;
    var h = screen.height || window.innerHeight;
    var diag = Math.sqrt(w * w + h * h);
    if (/android/i.test(navigator.userAgent) || /iPad|iPhone|iPod/.test(navigator.userAgent)) {
      return diag > 1400 ? 'Tablet' : 'Phone';
    }
    return 'Desktop';
  }

  function generateTimingTable() {
    var table = [];
    for (var i = 0; i < NUM_TIMING_OPTIONS; i++) {
      var ps = 0.0002 + Math.random() * 0.0001;
      var last4 = Math.floor(ps * 1e7) % 10000;
      ps = 0.0002 + last4 / 1e7;
      table.push({ index: i, picoseconds: ps });
    }
    table.sort(function (a, b) { return a.picoseconds - b.picoseconds; });
    for (var j = 0; j < table.length; j++) table[j].index = j;
    return table;
  }

  function selectRandom(table) {
    return table[Math.floor(Math.random() * table.length)];
  }

  function selectRnd45() {
    return Math.floor(Math.random() * MIN_TIMING_OPTIONS);
  }

  function formatSci(value, precision) {
    return value.toExponential(precision || 7);
  }

  function padLeft(str, width) {
    while (str.length < width) str = ' ' + str;
    return str;
  }

  function padRight(str, width) {
    while (str.length < width) str += ' ';
    return str;
  }

  function formatValue(label, value, unit) {
    return '  ' + padRight(label, 28) + padLeft(formatSci(value), 18) + ' ' + unit;
  }

  function dramBlockSize(formFactor) {
    if (formFactor === 'Phone') return 1 * 1024 * 1024;
    if (formFactor === 'Tablet') return 2 * 1024 * 1024;
    return 4 * 1024 * 1024;
  }

  function loaderBarWidth(formFactor) {
    if (formFactor === 'Phone') return 24;
    if (formFactor === 'Tablet') return 36;
    return 50;
  }

  function platformInitIterations(formFactor) {
    if (formFactor === 'Phone') return 40000;
    if (formFactor === 'Tablet') return 60000;
    return 100000;
  }

  function runDramPass(passNum, blockSize) {
    var buffer = new Uint8Array(blockSize);
    var start = performance.now();
    var passes = 0;
    var elapsed = 0;

    while (elapsed < DRAM_PASS_TARGET_MS) {
      for (var i = 0; i < blockSize; i += 64) {
        buffer[i] = (i + passNum) & 0xFF;
      }
      passes++;
      elapsed = performance.now() - start;
    }

    var totalBytes = blockSize * passes;
    var throughput = (totalBytes / (elapsed / 1000)) / (1024 * 1024);

    var latStart = performance.now();
    var sink = 0;
    for (var j = 0; j < 10000; j++) {
      var idx = (j * 7919) % blockSize;
      sink = buffer[idx];
    }
    var latEnd = performance.now();
    var latencyNs = ((latEnd - latStart) * 1e6) / 10000;

    return {
      pass_number: passNum,
      elapsed_sec: elapsed / 1000,
      throughput_mbps: throughput,
      latency_ns: latencyNs,
      regions: 15 + passNum,
      acceleration: 1.0 + passNum * 0.05
    };
  }

  function computeSpeedups(result) {
    var avg = 0;
    for (var i = 0; i < DRAM_LOOP_COUNT; i++) avg += result.dram_passes[i].throughput_mbps;
    avg /= DRAM_LOOP_COUNT;

    var tf = 0.0003 / result.selected_timing_ps;
    var df = avg / 1000.0;

    result.browser_speedup_pct = Math.max(BROWSER_SPEEDUP_MIN, BROWSER_SPEEDUP_MIN * tf * df);
    result.network_speedup_pct = Math.max(NETWORK_SPEEDUP_MIN, NETWORK_SPEEDUP_MIN * tf * df);
    result.screen_speedup_pct = SCREEN_SPEEDUP_MIN + (SCREEN_SPEEDUP_MAX - SCREEN_SPEEDUP_MIN) * (tf * df - 1.0);
    result.screen_speedup_pct = Math.max(SCREEN_SPEEDUP_MIN, Math.min(SCREEN_SPEEDUP_MAX, result.screen_speedup_pct));
  }

  class AI2ORBITBoot extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
      this._output = this.shadowRoot.getElementById('output');
      this._result = null;
      this._running = false;
    }

    static get observedAttributes() {
      return ['platform', 'form-factor', 'autostart'];
    }

    connectedCallback() {
      if (this.hasAttribute('autostart')) {
        this.startBoot();
      }
    }

    getResult() {
      return this._result;
    }

    _emit(html) {
      var line = document.createElement('div');
      line.innerHTML = html;
      this._output.appendChild(line);
      this.scrollTop = this.scrollHeight;
    }

    _emitStatus(msg) {
      this._emit('<span class="status">  AI2ORBIT ' + msg + '</span>');
    }

    _emitValue(label, value, unit) {
      this._emit('<span class="value">' + this._escHtml(formatValue(label, value, unit)) + '</span>');
    }

    _escHtml(text) {
      return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    _fireEvent(name, detail) {
      this.dispatchEvent(new CustomEvent(name, { detail: detail, bubbles: true, composed: true }));
    }

    async startBoot() {
      if (this._running) return;
      this._running = true;
      this._output.innerHTML = '';

      var platform = this.getAttribute('platform') || detectPlatform();
      var formFactor = this.getAttribute('form-factor') || detectFormFactor();
      var result = {
        platform: platform,
        form_factor: formFactor,
        selected_timing_ps: 0,
        selected_index: 0,
        rnd45_value: 0,
        loader_time_sec: 0,
        platform_time_sec: 0,
        dram_passes: [],
        total_boot_sec: 0,
        browser_speedup_pct: 0,
        network_speedup_pct: 0,
        screen_speedup_pct: 0,
        ready: false
      };

      var totalStart = performance.now();

      // Header
      this._emit('<pre class="header">\n' +
        '  ================================================================\n' +
        '      ___   ____  ___   ____  ____  ____  ______\n' +
        '     /   | /  _/ / _ \\ / __ \\/ __ )/ / / /_  __/\n' +
        '    / /| | / /  / /_/ // /_/ / __ / / / / / /\n' +
        '   / ___ |/ /  /  ___// _, _/ /_/ / /_/ / / /\n' +
        '  /_/  |_/___/ /_/   /_/ |_/_____/\\____/ /_/\n' +
        '\n' +
        '  BOOTLOADER v' + VERSION + '\n' +
        '  Platform: ' + platform + ' (' + formFactor + ')\n' +
        '  ================================================================\n</pre>');

      await this._sleep(50);

      // STEP 1: Timing
      this._emitStatus('..selecting timing');
      var timingTable = generateTimingTable();
      var selected = selectRandom(timingTable);
      result.selected_timing_ps = selected.picoseconds;
      result.selected_index = selected.index;
      this._emitValue('Selected [' + selected.index + '/244]:', selected.picoseconds, 'ps');

      this._emitStatus('..timing table sample:');
      var sampleCount = (formFactor === 'Desktop') ? 8 : 4;
      for (var i = 0; i < sampleCount && i < NUM_TIMING_OPTIONS; i++) {
        this._emitValue('  [' + timingTable[i].index + ']:', timingTable[i].picoseconds, 'ps');
      }
      this._emit('<span class="value">  ... (' + (NUM_TIMING_OPTIONS - sampleCount) + ' more)</span>');
      this._fireEvent('boot-progress', { stage: 'timing', progress: 0.1 });

      await this._sleep(50);

      // STEP 2: Loader bar
      this._emitStatus('..running system loader');
      var barWidth = loaderBarWidth(formFactor);
      var loaderStart = performance.now();
      await this._runLoaderBar(barWidth);
      result.loader_time_sec = (performance.now() - loaderStart) / 1000;
      this._emitValue('Loader time:', result.loader_time_sec, 'sec');
      this._fireEvent('boot-progress', { stage: 'loader', progress: 0.3 });

      // STEP 3: Platform init
      this._emitStatus('..starting platform');
      var platStart = performance.now();
      var iterations = platformInitIterations(formFactor);
      var acc = 0;
      for (var pi = 0; pi < iterations; pi++) {
        acc += Math.sin(pi * 0.00001) * Math.cos(pi * 0.000005);
      }
      result.platform_time_sec = (performance.now() - platStart) / 1000;
      this._emitValue('Platform init:', result.platform_time_sec, 'sec');
      this._fireEvent('boot-progress', { stage: 'platform_init', progress: 0.4 });

      await this._sleep(30);

      // STEP 4: RND45
      this._emitStatus('..selecting RND45');
      result.rnd45_value = selectRnd45();
      this._emitValue('RND45 selected:', result.rnd45_value, '');
      this._fireEvent('boot-progress', { stage: 'rnd45', progress: 0.5 });

      // STEP 5-6: DRAM mapper 4x
      this._emitStatus('..running DRAM mapper (4 passes)');
      var blockSize = dramBlockSize(formFactor);
      for (var pass = 0; pass < DRAM_LOOP_COUNT; pass++) {
        this._emitStatus('..DRAM pass ' + (pass + 1) + '/' + DRAM_LOOP_COUNT);
        await this._sleep(20);

        var dr = runDramPass(pass + 1, blockSize);
        result.dram_passes.push(dr);

        this._emitValue('  Throughput:', dr.throughput_mbps, 'MB/s');
        this._emitValue('  Latency:', dr.latency_ns, 'ns');
        this._emitValue('  Regions:', dr.regions, '');
        this._emitValue('  Acceleration:', dr.acceleration, 'x');
        this._emitValue('  Time:', dr.elapsed_sec, 'sec');
        this._fireEvent('boot-progress', { stage: 'dram_pass_' + (pass + 1), progress: 0.5 + (pass + 1) * 0.1 });
      }

      // Compute speedups
      computeSpeedups(result);

      result.total_boot_sec = (performance.now() - totalStart) / 1000;
      result.ready = true;

      // READY
      this._emit('');
      this._emit('<span class="ready-banner">' +
        '  ================================================================\n' +
        '  READY\n' +
        '  ================================================================</span>');
      this._emit('');

      this._emitValue('Selected timing:', result.selected_timing_ps, 'ps');
      this._emitValue('RND45:', result.rnd45_value, '');
      this._emitValue('Loader:', result.loader_time_sec, 'sec');
      this._emitValue('Platform:', result.platform_time_sec, 'sec');

      var dramAvg = 0;
      for (var d = 0; d < DRAM_LOOP_COUNT; d++) dramAvg += result.dram_passes[d].throughput_mbps;
      dramAvg /= DRAM_LOOP_COUNT;
      this._emitValue('DRAM (4x avg):', dramAvg, 'MB/s');
      this._emit('');
      this._emitValue('Browser speedup:', result.browser_speedup_pct, '%');
      this._emitValue('Network speedup:', result.network_speedup_pct, '%');
      this._emitValue('Screen speedup:', result.screen_speedup_pct, '%');
      this._emitValue('Total boot time:', result.total_boot_sec, 'sec');
      this._emit('');
      this._emit('<span class="copyright">  AI2ORBIT Co. 2026. All rights reserved.</span>');

      this._result = result;
      this._running = false;
      this._fireEvent('boot-ready', { result: result });
    }

    async _runLoaderBar(barWidth) {
      var barEl = document.createElement('div');
      barEl.className = 'bar-container';
      this._output.appendChild(barEl);

      var start = performance.now();
      var elapsed = 0;

      while (elapsed < LOADER_DURATION_MS) {
        var frac = elapsed / LOADER_DURATION_MS;
        var filled = Math.floor(frac * barWidth);
        var bar = '  [';
        for (var i = 0; i < barWidth; i++) {
          if (i < filled) bar += '#';
          else if (i === filled) bar += '>';
          else bar += ' ';
        }
        bar += '] ' + Math.floor(frac * 100) + '%';
        barEl.textContent = bar;

        await this._sleep(15);
        elapsed = performance.now() - start;
      }

      var finalBar = '  [';
      for (var j = 0; j < barWidth; j++) finalBar += '#';
      finalBar += '] 100%';
      barEl.textContent = finalBar;
    }

    _sleep(ms) {
      return new Promise(function (resolve) { setTimeout(resolve, ms); });
    }
  }

  if (typeof customElements !== 'undefined') {
    customElements.define('ai2orbit-boot', AI2ORBITBoot);
  }

  if (typeof window !== 'undefined') {
    window.AI2ORBITBoot = AI2ORBITBoot;
  }

})();
